import { Property, SearchFilters } from '@/types/property';

// Mock property data
const mockProperties: Property[] = [
  {
    id: '1',
    title: 'Modern Family Home',
    price: 485000,
    location: {
      city: 'San Francisco',
      state: 'CA',
      address: '2847 Oak Street',
    },
    images: [
      'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800',
      'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800',
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800',
    ],
    type: 'house',
    status: 'for-sale',
    bedrooms: 4,
    bathrooms: 3,
    area: 2400,
    yearBuilt: 2018,
    description: 'Beautiful modern family home with spacious living areas, updated kitchen, and large backyard. Perfect for families looking for comfort and style.',
    features: ['Pool', 'Garage', 'Garden', 'Smart Home', 'Solar Panels'],
    agent: {
      name: 'Sarah Johnson',
      phone: '(415) 555-0123',
      email: 'sarah.j@realestatepro.com',
    },
    createdAt: '2026-01-01',
    isFeatured: true,
  },
  {
    id: '2',
    title: 'Downtown Luxury Apartment',
    price: 3200,
    location: {
      city: 'New York',
      state: 'NY',
      address: '456 5th Avenue',
    },
    images: [
      'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800',
      'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800',
    ],
    type: 'apartment',
    status: 'for-rent',
    bedrooms: 2,
    bathrooms: 2,
    area: 1200,
    yearBuilt: 2020,
    description: 'Stunning luxury apartment in the heart of downtown with breathtaking city views. Modern amenities and prime location.',
    features: ['Gym', 'Concierge', 'Rooftop', 'Parking'],
    agent: {
      name: 'Michael Chen',
      phone: '(212) 555-0198',
      email: 'michael.c@realestatepro.com',
    },
    createdAt: '2025-12-28',
    isFeatured: true,
  },
  {
    id: '3',
    title: 'Cozy Suburban Townhouse',
    price: 325000,
    location: {
      city: 'Austin',
      state: 'TX',
      address: '789 Maple Drive',
    },
    images: [
      'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=800',
      'https://images.unsplash.com/photo-1570129477492-45c003edd2be?w=800',
    ],
    type: 'townhouse',
    status: 'for-sale',
    bedrooms: 3,
    bathrooms: 2,
    area: 1800,
    yearBuilt: 2015,
    description: 'Charming townhouse in quiet suburban neighborhood. Perfect starter home with modern updates and great community amenities.',
    features: ['Patio', 'Community Pool', 'Updated Kitchen'],
    agent: {
      name: 'Emily Rodriguez',
      phone: '(512) 555-0147',
      email: 'emily.r@realestatepro.com',
    },
    createdAt: '2025-12-25',
  },
  {
    id: '4',
    title: 'Beachfront Condo',
    price: 675000,
    location: {
      city: 'Miami',
      state: 'FL',
      address: '123 Ocean Boulevard',
    },
    images: [
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800',
      'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800',
    ],
    type: 'condo',
    status: 'for-sale',
    bedrooms: 3,
    bathrooms: 2,
    area: 1650,
    yearBuilt: 2019,
    description: 'Spectacular beachfront condo with panoramic ocean views. Resort-style living with premium finishes throughout.',
    features: ['Beach Access', 'Pool', 'Gym', 'Balcony', 'Ocean View'],
    agent: {
      name: 'David Martinez',
      phone: '(305) 555-0189',
      email: 'david.m@realestatepro.com',
    },
    createdAt: '2025-12-30',
    isFeatured: true,
  },
  {
    id: '5',
    title: 'Spacious Urban Loft',
    price: 2800,
    location: {
      city: 'Seattle',
      state: 'WA',
      address: '567 Pine Street',
    },
    images: [
      'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800',
      'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800',
    ],
    type: 'apartment',
    status: 'for-rent',
    bedrooms: 1,
    bathrooms: 1,
    area: 950,
    yearBuilt: 2021,
    description: 'Industrial-chic loft with high ceilings and exposed brick. Modern kitchen and open floor plan ideal for professionals.',
    features: ['High Ceilings', 'Exposed Brick', 'In-Unit Laundry', 'Parking'],
    agent: {
      name: 'Lisa Thompson',
      phone: '(206) 555-0134',
      email: 'lisa.t@realestatepro.com',
    },
    createdAt: '2025-12-27',
  },
  {
    id: '6',
    title: 'Country Estate',
    price: 1250000,
    location: {
      city: 'Nashville',
      state: 'TN',
      address: '890 Country Lane',
    },
    images: [
      'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800',
      'https://images.unsplash.com/photo-1572120360610-d971b9d7767c?w=800',
    ],
    type: 'house',
    status: 'for-sale',
    bedrooms: 5,
    bathrooms: 4,
    area: 4200,
    yearBuilt: 2017,
    description: 'Luxurious country estate on 5 acres. Custom-built home with premium finishes, guest house, and stunning landscape.',
    features: ['Guest House', 'Pool', 'Tennis Court', 'Wine Cellar', '5 Acres'],
    agent: {
      name: 'Robert Williams',
      phone: '(615) 555-0176',
      email: 'robert.w@realestatepro.com',
    },
    createdAt: '2025-12-26',
    isFeatured: true,
  },
];

export const propertyService = {
  // Get all properties
  getAllProperties: async (): Promise<Property[]> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 300));
    return mockProperties;
  },

  // Get featured properties
  getFeaturedProperties: async (): Promise<Property[]> => {
    await new Promise(resolve => setTimeout(resolve, 200));
    return mockProperties.filter(p => p.isFeatured);
  },

  // Get property by ID
  getPropertyById: async (id: string): Promise<Property | null> => {
    await new Promise(resolve => setTimeout(resolve, 200));
    return mockProperties.find(p => p.id === id) || null;
  },

  // Search properties with filters
  searchProperties: async (filters: SearchFilters): Promise<Property[]> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    
    let results = [...mockProperties];

    if (filters.location) {
      const searchTerm = filters.location.toLowerCase();
      results = results.filter(p => 
        p.location.city.toLowerCase().includes(searchTerm) ||
        p.location.state.toLowerCase().includes(searchTerm) ||
        p.location.address.toLowerCase().includes(searchTerm)
      );
    }

    if (filters.priceMin !== undefined) {
      results = results.filter(p => p.price >= filters.priceMin!);
    }

    if (filters.priceMax !== undefined) {
      results = results.filter(p => p.price <= filters.priceMax!);
    }

    if (filters.propertyType && filters.propertyType !== 'all') {
      results = results.filter(p => p.type === filters.propertyType);
    }

    if (filters.status && filters.status !== 'all') {
      results = results.filter(p => p.status === filters.status);
    }

    if (filters.bedrooms !== undefined) {
      results = results.filter(p => p.bedrooms >= filters.bedrooms!);
    }

    if (filters.bathrooms !== undefined) {
      results = results.filter(p => p.bathrooms >= filters.bathrooms!);
    }

    if (filters.areaMin !== undefined) {
      results = results.filter(p => p.area >= filters.areaMin!);
    }

    if (filters.areaMax !== undefined) {
      results = results.filter(p => p.area <= filters.areaMax!);
    }

    return results;
  },

  // Format price
  formatPrice: (price: number, status: Property['status']): string => {
    const formatted = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);

    return status === 'for-rent' ? `${formatted}/mo` : formatted;
  },

  // Format area
  formatArea: (area: number): string => {
    return `${area.toLocaleString()} sq ft`;
  },
};
