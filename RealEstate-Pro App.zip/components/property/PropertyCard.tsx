import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { Image } from 'expo-image';
import { Ionicons } from '@expo/vector-icons';
import { Property } from '@/types/property';
import { propertyService } from '@/services/propertyService';
import { theme } from '@/constants/theme';

interface PropertyCardProps {
  property: Property;
  onPress: () => void;
  onSavePress?: () => void;
  isSaved?: boolean;
}

export function PropertyCard({ property, onPress, onSavePress, isSaved }: PropertyCardProps) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.container, pressed && styles.pressed]}>
      <View style={styles.imageContainer}>
        <Image
          source={{ uri: property.images[0] }}
          style={styles.image}
          contentFit="cover"
        />
        {property.isFeatured && (
          <View style={styles.featuredBadge}>
            <Ionicons name="star" size={14} color={theme.colors.white} />
            <Text style={styles.featuredText}>Featured</Text>
          </View>
        )}
        {onSavePress && (
          <Pressable onPress={onSavePress} style={styles.saveButton}>
            <Ionicons
              name={isSaved ? 'heart' : 'heart-outline'}
              size={22}
              color={isSaved ? theme.colors.error : theme.colors.white}
            />
          </Pressable>
        )}
      </View>
      
      <View style={styles.content}>
        <View style={styles.priceRow}>
          <Text style={styles.price}>{propertyService.formatPrice(property.price, property.status)}</Text>
          <View style={styles.statusBadge}>
            <Text style={styles.statusText}>
              {property.status === 'for-sale' ? 'For Sale' : 'For Rent'}
            </Text>
          </View>
        </View>
        
        <Text style={styles.title} numberOfLines={1}>{property.title}</Text>
        
        <View style={styles.locationRow}>
          <Ionicons name="location" size={16} color={theme.colors.primary} />
          <Text style={styles.location} numberOfLines={1}>
            {property.location.city}, {property.location.state}
          </Text>
        </View>
        
        <View style={styles.specs}>
          <View style={styles.spec}>
            <Ionicons name="bed" size={16} color={theme.colors.textSecondary} />
            <Text style={styles.specText}>{property.bedrooms}</Text>
          </View>
          <View style={styles.spec}>
            <Ionicons name="water" size={16} color={theme.colors.textSecondary} />
            <Text style={styles.specText}>{property.bathrooms}</Text>
          </View>
          <View style={styles.spec}>
            <Ionicons name="expand" size={16} color={theme.colors.textSecondary} />
            <Text style={styles.specText}>{propertyService.formatArea(property.area)}</Text>
          </View>
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: theme.colors.white,
    borderRadius: theme.borderRadius.lg,
    overflow: 'hidden',
    ...theme.shadows.md,
  },
  
  pressed: {
    opacity: 0.9,
    transform: [{ scale: 0.98 }],
  },
  
  imageContainer: {
    position: 'relative',
    height: 200,
  },
  
  image: {
    width: '100%',
    height: '100%',
  },
  
  featuredBadge: {
    position: 'absolute',
    top: theme.spacing.md,
    left: theme.spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.warning,
    paddingHorizontal: theme.spacing.sm,
    paddingVertical: theme.spacing.xs,
    borderRadius: theme.borderRadius.sm,
    gap: 4,
  },
  
  featuredText: {
    color: theme.colors.white,
    fontSize: theme.fontSizes.xs,
    fontWeight: '600',
  },
  
  saveButton: {
    position: 'absolute',
    top: theme.spacing.md,
    right: theme.spacing.md,
    width: 36,
    height: 36,
    borderRadius: theme.borderRadius.full,
    backgroundColor: 'rgba(0,0,0,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  
  content: {
    padding: theme.spacing.md,
    gap: theme.spacing.sm,
  },
  
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  
  price: {
    fontSize: theme.fontSizes['2xl'],
    fontWeight: '700',
    color: theme.colors.primary,
  },
  
  statusBadge: {
    backgroundColor: theme.colors.primaryLight,
    paddingHorizontal: theme.spacing.sm,
    paddingVertical: 4,
    borderRadius: theme.borderRadius.sm,
  },
  
  statusText: {
    color: theme.colors.white,
    fontSize: theme.fontSizes.xs,
    fontWeight: '600',
  },
  
  title: {
    fontSize: theme.fontSizes.lg,
    fontWeight: '600',
    color: theme.colors.text,
  },
  
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  
  location: {
    flex: 1,
    fontSize: theme.fontSizes.sm,
    color: theme.colors.textSecondary,
  },
  
  specs: {
    flexDirection: 'row',
    gap: theme.spacing.md,
    marginTop: theme.spacing.xs,
  },
  
  spec: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  
  specText: {
    fontSize: theme.fontSizes.sm,
    color: theme.colors.textSecondary,
  },
});
