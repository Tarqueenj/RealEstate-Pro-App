import React, { useState } from 'react';
import { View, Text, StyleSheet, Modal, ScrollView, Pressable } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { SearchFilters, Property } from '@/types/property';
import { Button } from '@/components/ui/Button';
import { theme } from '@/constants/theme';

interface FilterModalProps {
  visible: boolean;
  onClose: () => void;
  filters: SearchFilters;
  onApply: (filters: SearchFilters) => void;
}

export function FilterModal({ visible, onClose, filters, onApply }: FilterModalProps) {
  const insets = useSafeAreaInsets();
  const [localFilters, setLocalFilters] = useState<SearchFilters>(filters);

  const propertyTypes: Array<{ value: Property['type'] | 'all'; label: string }> = [
    { value: 'all', label: 'All Types' },
    { value: 'house', label: 'House' },
    { value: 'apartment', label: 'Apartment' },
    { value: 'condo', label: 'Condo' },
    { value: 'townhouse', label: 'Townhouse' },
    { value: 'land', label: 'Land' },
  ];

  const statuses: Array<{ value: Property['status'] | 'all'; label: string }> = [
    { value: 'all', label: 'All' },
    { value: 'for-sale', label: 'For Sale' },
    { value: 'for-rent', label: 'For Rent' },
  ];

  const bedroomOptions = [
    { value: undefined, label: 'Any' },
    { value: 1, label: '1+' },
    { value: 2, label: '2+' },
    { value: 3, label: '3+' },
    { value: 4, label: '4+' },
    { value: 5, label: '5+' },
  ];

  const handleApply = () => {
    onApply(localFilters);
    onClose();
  };

  const handleReset = () => {
    setLocalFilters({ propertyType: 'all', status: 'all' });
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <View style={styles.overlay}>
        <View style={[styles.container, { paddingBottom: Math.max(insets.bottom, theme.spacing.md) }]}>
          <View style={styles.header}>
            <Text style={styles.title}>Filters</Text>
            <Pressable onPress={onClose} hitSlop={8}>
              <Ionicons name="close" size={28} color={theme.colors.text} />
            </Pressable>
          </View>

          <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Property Type</Text>
              <View style={styles.options}>
                {propertyTypes.map(type => (
                  <Pressable
                    key={type.value}
                    onPress={() => setLocalFilters({ ...localFilters, propertyType: type.value })}
                    style={[
                      styles.option,
                      localFilters.propertyType === type.value && styles.optionActive,
                    ]}
                  >
                    <Text
                      style={[
                        styles.optionText,
                        localFilters.propertyType === type.value && styles.optionTextActive,
                      ]}
                    >
                      {type.label}
                    </Text>
                  </Pressable>
                ))}
              </View>
            </View>

            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Status</Text>
              <View style={styles.options}>
                {statuses.map(status => (
                  <Pressable
                    key={status.value}
                    onPress={() => setLocalFilters({ ...localFilters, status: status.value })}
                    style={[
                      styles.option,
                      localFilters.status === status.value && styles.optionActive,
                    ]}
                  >
                    <Text
                      style={[
                        styles.optionText,
                        localFilters.status === status.value && styles.optionTextActive,
                      ]}
                    >
                      {status.label}
                    </Text>
                  </Pressable>
                ))}
              </View>
            </View>

            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Bedrooms</Text>
              <View style={styles.options}>
                {bedroomOptions.map(option => (
                  <Pressable
                    key={option.label}
                    onPress={() => setLocalFilters({ ...localFilters, bedrooms: option.value })}
                    style={[
                      styles.option,
                      localFilters.bedrooms === option.value && styles.optionActive,
                    ]}
                  >
                    <Text
                      style={[
                        styles.optionText,
                        localFilters.bedrooms === option.value && styles.optionTextActive,
                      ]}
                    >
                      {option.label}
                    </Text>
                  </Pressable>
                ))}
              </View>
            </View>

            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Bathrooms</Text>
              <View style={styles.options}>
                {bedroomOptions.map(option => (
                  <Pressable
                    key={option.label}
                    onPress={() => setLocalFilters({ ...localFilters, bathrooms: option.value })}
                    style={[
                      styles.option,
                      localFilters.bathrooms === option.value && styles.optionActive,
                    ]}
                  >
                    <Text
                      style={[
                        styles.optionText,
                        localFilters.bathrooms === option.value && styles.optionTextActive,
                      ]}
                    >
                      {option.label}
                    </Text>
                  </Pressable>
                ))}
              </View>
            </View>
          </ScrollView>

          <View style={styles.footer}>
            <Button title="Reset" onPress={handleReset} variant="outline" style={{ flex: 1 }} />
            <Button title="Apply Filters" onPress={handleApply} style={{ flex: 1 }} />
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  
  container: {
    backgroundColor: theme.colors.white,
    borderTopLeftRadius: theme.borderRadius.xl,
    borderTopRightRadius: theme.borderRadius.xl,
    maxHeight: '85%',
  },
  
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: theme.spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.border,
  },
  
  title: {
    fontSize: theme.fontSizes.xl,
    fontWeight: '700',
    color: theme.colors.text,
  },
  
  content: {
    padding: theme.spacing.lg,
  },
  
  section: {
    marginBottom: theme.spacing.xl,
  },
  
  sectionTitle: {
    fontSize: theme.fontSizes.lg,
    fontWeight: '600',
    color: theme.colors.text,
    marginBottom: theme.spacing.md,
  },
  
  options: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: theme.spacing.sm,
  },
  
  option: {
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.sm,
    borderRadius: theme.borderRadius.lg,
    borderWidth: 1.5,
    borderColor: theme.colors.border,
    backgroundColor: theme.colors.white,
  },
  
  optionActive: {
    backgroundColor: theme.colors.primary,
    borderColor: theme.colors.primary,
  },
  
  optionText: {
    fontSize: theme.fontSizes.sm,
    fontWeight: '500',
    color: theme.colors.text,
  },
  
  optionTextActive: {
    color: theme.colors.white,
  },
  
  footer: {
    flexDirection: 'row',
    gap: theme.spacing.md,
    padding: theme.spacing.lg,
    borderTopWidth: 1,
    borderTopColor: theme.colors.border,
  },
});
