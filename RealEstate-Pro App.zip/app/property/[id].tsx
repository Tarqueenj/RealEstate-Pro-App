import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Dimensions, Pressable, Linking } from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { Image } from 'expo-image';
import { Ionicons } from '@expo/vector-icons';
import { useProperty } from '@/hooks/useProperties';
import { useSavedProperties } from '@/hooks/useSavedProperties';
import { propertyService } from '@/services/propertyService';
import { Button } from '@/components/ui/Button';
import { theme } from '@/constants/theme';
import { useAlert } from '@/template';

const { width } = Dimensions.get('window');

export default function PropertyDetailScreen() {
  const { id } = useLocalSearchParams();
  const { property, loading } = useProperty(id as string);
  const { toggleSave, isSaved } = useSavedProperties();
  const { showAlert } = useAlert();
  const [activeImageIndex, setActiveImageIndex] = useState(0);

  if (loading || !property) {
    return (
      <View style={styles.loadingContainer}>
        <Text>Loading...</Text>
      </View>
    );
  }

  const handleContact = (method: 'phone' | 'email') => {
    if (!property.agent) return;
    
    if (method === 'phone') {
      Linking.openURL(`tel:${property.agent.phone}`);
    } else {
      Linking.openURL(`mailto:${property.agent.email}`);
    }
  };

  return (
    <View style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.imageGallery}>
          <ScrollView
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            onScroll={(e) => {
              const index = Math.round(e.nativeEvent.contentOffset.x / width);
              setActiveImageIndex(index);
            }}
            scrollEventThrottle={16}
          >
            {property.images.map((image, index) => (
              <Image key={index} source={{ uri: image }} style={styles.image} contentFit="cover" />
            ))}
          </ScrollView>
          <View style={styles.imageDots}>
            {property.images.map((_, index) => (
              <View
                key={index}
                style={[styles.dot, index === activeImageIndex && styles.dotActive]}
              />
            ))}
          </View>
        </View>

        <View style={styles.content}>
          <View style={styles.priceSection}>
            <Text style={styles.price}>{propertyService.formatPrice(property.price, property.status)}</Text>
            <Pressable onPress={() => toggleSave(property.id)} style={styles.saveButton}>
              <Ionicons
                name={isSaved(property.id) ? 'heart' : 'heart-outline'}
                size={28}
                color={isSaved(property.id) ? theme.colors.error : theme.colors.text}
              />
            </Pressable>
          </View>

          <Text style={styles.title}>{property.title}</Text>

          <View style={styles.locationRow}>
            <Ionicons name="location" size={20} color={theme.colors.primary} />
            <Text style={styles.location}>{property.location.address}</Text>
          </View>
          <Text style={styles.locationDetail}>
            {property.location.city}, {property.location.state}
          </Text>

          <View style={styles.specsCard}>
            <View style={styles.specItem}>
              <Ionicons name="bed" size={24} color={theme.colors.primary} />
              <Text style={styles.specValue}>{property.bedrooms}</Text>
              <Text style={styles.specLabel}>Bedrooms</Text>
            </View>
            <View style={styles.divider} />
            <View style={styles.specItem}>
              <Ionicons name="water" size={24} color={theme.colors.primary} />
              <Text style={styles.specValue}>{property.bathrooms}</Text>
              <Text style={styles.specLabel}>Bathrooms</Text>
            </View>
            <View style={styles.divider} />
            <View style={styles.specItem}>
              <Ionicons name="expand" size={24} color={theme.colors.primary} />
              <Text style={styles.specValue}>{property.area.toLocaleString()}</Text>
              <Text style={styles.specLabel}>Sq Ft</Text>
            </View>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Description</Text>
            <Text style={styles.description}>{property.description}</Text>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Features</Text>
            <View style={styles.features}>
              {property.features.map((feature, index) => (
                <View key={index} style={styles.featureItem}>
                  <Ionicons name="checkmark-circle" size={20} color={theme.colors.secondary} />
                  <Text style={styles.featureText}>{feature}</Text>
                </View>
              ))}
            </View>
          </View>

          {property.agent && (
            <View style={styles.agentCard}>
              <View style={styles.agentHeader}>
                <View style={styles.agentAvatar}>
                  <Text style={styles.agentAvatarText}>
                    {property.agent.name.split(' ').map(n => n[0]).join('')}
                  </Text>
                </View>
                <View style={styles.agentInfo}>
                  <Text style={styles.agentName}>{property.agent.name}</Text>
                  <Text style={styles.agentTitle}>Licensed Agent</Text>
                </View>
              </View>
              <View style={styles.agentActions}>
                <Pressable
                  style={({ pressed }) => [styles.agentButton, pressed && styles.agentButtonPressed]}
                  onPress={() => handleContact('phone')}
                >
                  <Ionicons name="call" size={20} color={theme.colors.primary} />
                  <Text style={styles.agentButtonText}>Call</Text>
                </Pressable>
                <Pressable
                  style={({ pressed }) => [styles.agentButton, pressed && styles.agentButtonPressed]}
                  onPress={() => handleContact('email')}
                >
                  <Ionicons name="mail" size={20} color={theme.colors.primary} />
                  <Text style={styles.agentButtonText}>Email</Text>
                </Pressable>
              </View>
            </View>
          )}
        </View>
      </ScrollView>

      <View style={styles.footer}>
        <Button
          title="Schedule Tour"
          onPress={() => showAlert('Schedule Tour', 'Tour scheduling feature coming soon')}
          style={{ flex: 1 }}
        />
        <Pressable
          style={({ pressed }) => [styles.compareButton, pressed && styles.compareButtonPressed]}
          onPress={() => showAlert('Add to Compare', 'Compare feature coming soon')}
        >
          <Ionicons name="git-compare" size={24} color={theme.colors.white} />
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.white,
  },

  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },

  imageGallery: {
    position: 'relative',
    height: 300,
  },

  image: {
    width,
    height: 300,
  },

  imageDots: {
    position: 'absolute',
    bottom: theme.spacing.md,
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'center',
    gap: theme.spacing.xs,
  },

  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.5)',
  },

  dotActive: {
    backgroundColor: theme.colors.white,
  },

  content: {
    padding: theme.spacing.lg,
  },

  priceSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing.md,
  },

  price: {
    fontSize: theme.fontSizes['3xl'],
    fontWeight: '700',
    color: theme.colors.primary,
  },

  saveButton: {
    width: 44,
    height: 44,
    borderRadius: theme.borderRadius.full,
    backgroundColor: theme.colors.surface,
    justifyContent: 'center',
    alignItems: 'center',
  },

  title: {
    fontSize: theme.fontSizes['2xl'],
    fontWeight: '700',
    color: theme.colors.text,
    marginBottom: theme.spacing.sm,
  },

  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },

  location: {
    fontSize: theme.fontSizes.base,
    fontWeight: '500',
    color: theme.colors.text,
  },

  locationDetail: {
    fontSize: theme.fontSizes.sm,
    color: theme.colors.textSecondary,
    marginTop: 2,
  },

  specsCard: {
    flexDirection: 'row',
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.lg,
    marginTop: theme.spacing.lg,
  },

  specItem: {
    flex: 1,
    alignItems: 'center',
  },

  divider: {
    width: 1,
    backgroundColor: theme.colors.border,
  },

  specValue: {
    fontSize: theme.fontSizes.xl,
    fontWeight: '700',
    color: theme.colors.text,
    marginTop: theme.spacing.sm,
  },

  specLabel: {
    fontSize: theme.fontSizes.xs,
    color: theme.colors.textSecondary,
    marginTop: 4,
  },

  section: {
    marginTop: theme.spacing.xl,
  },

  sectionTitle: {
    fontSize: theme.fontSizes.lg,
    fontWeight: '700',
    color: theme.colors.text,
    marginBottom: theme.spacing.md,
  },

  description: {
    fontSize: theme.fontSizes.base,
    color: theme.colors.textSecondary,
    lineHeight: 24,
  },

  features: {
    gap: theme.spacing.md,
  },

  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: theme.spacing.sm,
  },

  featureText: {
    fontSize: theme.fontSizes.base,
    color: theme.colors.text,
  },

  agentCard: {
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.lg,
    marginTop: theme.spacing.xl,
  },

  agentHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: theme.spacing.md,
  },

  agentAvatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: theme.colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: theme.spacing.md,
  },

  agentAvatarText: {
    fontSize: theme.fontSizes.lg,
    fontWeight: '700',
    color: theme.colors.white,
  },

  agentInfo: {
    flex: 1,
  },

  agentName: {
    fontSize: theme.fontSizes.lg,
    fontWeight: '600',
    color: theme.colors.text,
  },

  agentTitle: {
    fontSize: theme.fontSizes.sm,
    color: theme.colors.textSecondary,
    marginTop: 2,
  },

  agentActions: {
    flexDirection: 'row',
    gap: theme.spacing.md,
  },

  agentButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: theme.spacing.sm,
    backgroundColor: theme.colors.white,
    borderRadius: theme.borderRadius.md,
    paddingVertical: theme.spacing.md,
    borderWidth: 1.5,
    borderColor: theme.colors.primary,
  },

  agentButtonPressed: {
    opacity: 0.7,
  },

  agentButtonText: {
    fontSize: theme.fontSizes.base,
    fontWeight: '600',
    color: theme.colors.primary,
  },

  footer: {
    flexDirection: 'row',
    gap: theme.spacing.md,
    padding: theme.spacing.md,
    borderTopWidth: 1,
    borderTopColor: theme.colors.border,
  },

  compareButton: {
    width: 52,
    height: 52,
    borderRadius: theme.borderRadius.lg,
    backgroundColor: theme.colors.secondary,
    justifyContent: 'center',
    alignItems: 'center',
  },

  compareButtonPressed: {
    opacity: 0.7,
  },
});
