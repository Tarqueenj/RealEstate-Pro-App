import React from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { theme } from '@/constants/theme';
import { useAlert } from '@/template';

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const { showAlert } = useAlert();

  const menuItems = [
    { icon: 'person-outline', label: 'Edit Profile', value: '' },
    { icon: 'notifications-outline', label: 'Notifications', value: 'On' },
    { icon: 'heart-outline', label: 'Saved Properties', value: '8' },
    { icon: 'git-compare-outline', label: 'Compare List', value: '3' },
    { icon: 'document-text-outline', label: 'Documents', value: '' },
    { icon: 'settings-outline', label: 'Settings', value: '' },
    { icon: 'help-circle-outline', label: 'Help & Support', value: '' },
  ];

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <Text style={styles.title}>Profile</Text>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.profileCard}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>JD</Text>
          </View>
          <Text style={styles.name}>John Doe</Text>
          <Text style={styles.email}>john.doe@example.com</Text>
          <View style={styles.badge}>
            <Ionicons name="shield-checkmark" size={16} color={theme.colors.white} />
            <Text style={styles.badgeText}>Verified User</Text>
          </View>
        </View>

        <View style={styles.menuCard}>
          {menuItems.map((item, index) => (
            <Pressable
              key={index}
              style={({ pressed }) => [
                styles.menuItem,
                pressed && styles.menuItemPressed,
                index !== menuItems.length - 1 && styles.menuItemBorder,
              ]}
              onPress={() => showAlert('Coming Soon', `${item.label} feature will be available soon`)}
            >
              <View style={styles.menuLeft}>
                <Ionicons name={item.icon as any} size={22} color={theme.colors.text} />
                <Text style={styles.menuLabel}>{item.label}</Text>
              </View>
              <View style={styles.menuRight}>
                {item.value ? <Text style={styles.menuValue}>{item.value}</Text> : null}
                <Ionicons name="chevron-forward" size={20} color={theme.colors.textSecondary} />
              </View>
            </Pressable>
          ))}
        </View>

        <Pressable
          style={({ pressed }) => [styles.logoutButton, pressed && styles.logoutPressed]}
          onPress={() => showAlert('Logout', 'Are you sure you want to logout?', [
            { text: 'Cancel', style: 'cancel' },
            { text: 'Logout', style: 'destructive' },
          ])}
        >
          <Ionicons name="log-out-outline" size={22} color={theme.colors.error} />
          <Text style={styles.logoutText}>Logout</Text>
        </Pressable>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.surface,
  },

  header: {
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.md,
  },

  title: {
    fontSize: theme.fontSizes['2xl'],
    fontWeight: '700',
    color: theme.colors.text,
  },

  content: {
    flex: 1,
    paddingHorizontal: theme.spacing.md,
  },

  profileCard: {
    backgroundColor: theme.colors.white,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.xl,
    alignItems: 'center',
    ...theme.shadows.sm,
    marginBottom: theme.spacing.lg,
  },

  avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: theme.colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: theme.spacing.md,
  },

  avatarText: {
    fontSize: theme.fontSizes['3xl'],
    fontWeight: '700',
    color: theme.colors.white,
  },

  name: {
    fontSize: theme.fontSizes.xl,
    fontWeight: '700',
    color: theme.colors.text,
  },

  email: {
    fontSize: theme.fontSizes.sm,
    color: theme.colors.textSecondary,
    marginTop: 4,
  },

  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: theme.colors.secondary,
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.xs,
    borderRadius: theme.borderRadius.full,
    marginTop: theme.spacing.md,
  },

  badgeText: {
    fontSize: theme.fontSizes.xs,
    fontWeight: '600',
    color: theme.colors.white,
  },

  menuCard: {
    backgroundColor: theme.colors.white,
    borderRadius: theme.borderRadius.lg,
    overflow: 'hidden',
    ...theme.shadows.sm,
    marginBottom: theme.spacing.lg,
  },

  menuItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: theme.spacing.lg,
  },

  menuItemPressed: {
    backgroundColor: theme.colors.surface,
  },

  menuItemBorder: {
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.borderLight,
  },

  menuLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: theme.spacing.md,
  },

  menuLabel: {
    fontSize: theme.fontSizes.base,
    fontWeight: '500',
    color: theme.colors.text,
  },

  menuRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: theme.spacing.sm,
  },

  menuValue: {
    fontSize: theme.fontSizes.sm,
    color: theme.colors.textSecondary,
  },

  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: theme.spacing.sm,
    backgroundColor: theme.colors.white,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.lg,
    ...theme.shadows.sm,
    marginBottom: theme.spacing.lg,
  },

  logoutPressed: {
    opacity: 0.7,
  },

  logoutText: {
    fontSize: theme.fontSizes.base,
    fontWeight: '600',
    color: theme.colors.error,
  },
});
