import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { theme } from '@/constants/theme';

export default function CalculatorScreen() {
  const insets = useSafeAreaInsets();
  const [homePrice, setHomePrice] = useState('');
  const [downPayment, setDownPayment] = useState('20');
  const [interestRate, setInterestRate] = useState('6.5');
  const [loanTerm, setLoanTerm] = useState('30');

  const calculateMortgage = () => {
    const price = parseFloat(homePrice) || 0;
    const down = (parseFloat(downPayment) || 0) / 100;
    const rate = (parseFloat(interestRate) || 0) / 100 / 12;
    const months = (parseFloat(loanTerm) || 0) * 12;

    const principal = price * (1 - down);
    if (principal <= 0 || rate <= 0 || months <= 0) {
      return { monthly: 0, total: 0, interest: 0, downAmount: 0 };
    }

    const monthly = (principal * rate * Math.pow(1 + rate, months)) / (Math.pow(1 + rate, months) - 1);
    const total = monthly * months;
    const interest = total - principal;
    const downAmount = price * down;

    return { monthly, total, interest, downAmount };
  };

  const result = calculateMortgage();

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <Text style={styles.title}>Mortgage Calculator</Text>
        <Text style={styles.subtitle}>Estimate your monthly payments</Text>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.card}>
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Home Price</Text>
            <View style={styles.inputWrapper}>
              <Text style={styles.inputPrefix}>$</Text>
              <TextInput
                style={styles.input}
                value={homePrice}
                onChangeText={setHomePrice}
                placeholder="0"
                keyboardType="numeric"
                placeholderTextColor={theme.colors.textLight}
              />
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Down Payment (%)</Text>
            <View style={styles.inputWrapper}>
              <TextInput
                style={styles.input}
                value={downPayment}
                onChangeText={setDownPayment}
                placeholder="20"
                keyboardType="numeric"
                placeholderTextColor={theme.colors.textLight}
              />
              <Text style={styles.inputSuffix}>%</Text>
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Interest Rate (%)</Text>
            <View style={styles.inputWrapper}>
              <TextInput
                style={styles.input}
                value={interestRate}
                onChangeText={setInterestRate}
                placeholder="6.5"
                keyboardType="numeric"
                placeholderTextColor={theme.colors.textLight}
              />
              <Text style={styles.inputSuffix}>%</Text>
            </View>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Loan Term (years)</Text>
            <View style={styles.inputWrapper}>
              <TextInput
                style={styles.input}
                value={loanTerm}
                onChangeText={setLoanTerm}
                placeholder="30"
                keyboardType="numeric"
                placeholderTextColor={theme.colors.textLight}
              />
              <Text style={styles.inputSuffix}>years</Text>
            </View>
          </View>
        </View>

        <View style={styles.resultCard}>
          <View style={styles.resultHeader}>
            <Ionicons name="calculator" size={24} color={theme.colors.primary} />
            <Text style={styles.resultTitle}>Your Monthly Payment</Text>
          </View>
          <Text style={styles.monthlyPayment}>
            ${result.monthly.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </Text>

          <View style={styles.breakdown}>
            <View style={styles.breakdownItem}>
              <Text style={styles.breakdownLabel}>Down Payment</Text>
              <Text style={styles.breakdownValue}>
                ${result.downAmount.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
              </Text>
            </View>
            <View style={styles.breakdownItem}>
              <Text style={styles.breakdownLabel}>Total Interest</Text>
              <Text style={styles.breakdownValue}>
                ${result.interest.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
              </Text>
            </View>
            <View style={styles.breakdownItem}>
              <Text style={styles.breakdownLabel}>Total Payment</Text>
              <Text style={styles.breakdownValue}>
                ${result.total.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.surface,
  },

  header: {
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.md,
  },

  title: {
    fontSize: theme.fontSizes['2xl'],
    fontWeight: '700',
    color: theme.colors.text,
  },

  subtitle: {
    fontSize: theme.fontSizes.sm,
    color: theme.colors.textSecondary,
    marginTop: 4,
  },

  content: {
    flex: 1,
    paddingHorizontal: theme.spacing.md,
  },

  card: {
    backgroundColor: theme.colors.white,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.lg,
    ...theme.shadows.sm,
    marginBottom: theme.spacing.md,
  },

  inputGroup: {
    marginBottom: theme.spacing.lg,
  },

  label: {
    fontSize: theme.fontSizes.sm,
    fontWeight: '600',
    color: theme.colors.text,
    marginBottom: theme.spacing.sm,
  },

  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: theme.colors.surface,
    borderRadius: theme.borderRadius.md,
    paddingHorizontal: theme.spacing.md,
    borderWidth: 1.5,
    borderColor: theme.colors.border,
  },

  inputPrefix: {
    fontSize: theme.fontSizes.lg,
    fontWeight: '600',
    color: theme.colors.text,
    marginRight: theme.spacing.xs,
  },

  inputSuffix: {
    fontSize: theme.fontSizes.sm,
    fontWeight: '600',
    color: theme.colors.textSecondary,
    marginLeft: theme.spacing.xs,
  },

  input: {
    flex: 1,
    fontSize: theme.fontSizes.lg,
    fontWeight: '600',
    color: theme.colors.text,
    paddingVertical: theme.spacing.md,
  },

  resultCard: {
    backgroundColor: theme.colors.primary,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.xl,
    ...theme.shadows.md,
    marginBottom: theme.spacing.lg,
  },

  resultHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: theme.spacing.sm,
    marginBottom: theme.spacing.sm,
  },

  resultTitle: {
    fontSize: theme.fontSizes.base,
    fontWeight: '600',
    color: theme.colors.white,
  },

  monthlyPayment: {
    fontSize: 42,
    fontWeight: '700',
    color: theme.colors.white,
    marginBottom: theme.spacing.xl,
  },

  breakdown: {
    gap: theme.spacing.md,
  },

  breakdownItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  breakdownLabel: {
    fontSize: theme.fontSizes.sm,
    color: 'rgba(255,255,255,0.8)',
  },

  breakdownValue: {
    fontSize: theme.fontSizes.base,
    fontWeight: '600',
    color: theme.colors.white,
  },
});
