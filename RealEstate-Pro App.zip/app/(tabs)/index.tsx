import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, FlatList, Pressable } from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { useFeaturedProperties } from '@/hooks/useProperties';
import { useSavedProperties } from '@/hooks/useSavedProperties';
import { PropertyCard } from '@/components/property/PropertyCard';
import { SearchBar } from '@/components/ui/SearchBar';
import { theme } from '@/constants/theme';

export default function PropertiesScreen() {
  const insets = useSafeAreaInsets();
  const { properties, loading } = useFeaturedProperties();
  const { toggleSave, isSaved } = useSavedProperties();
  const [searchQuery, setSearchQuery] = useState('');

  const quickFilters = [
    { icon: 'home', label: 'Houses', value: 'house' },
    { icon: 'business', label: 'Apartments', value: 'apartment' },
    { icon: 'bed', label: '3+ Beds', value: '3bed' },
    { icon: 'cash', label: 'Under 500k', value: 'budget' },
  ];

  return (
    <View style={[styles.container, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Welcome back</Text>
          <Text style={styles.title}>Find Your Dream Home</Text>
        </View>
        <Pressable onPress={() => router.push('/messages')} style={styles.iconButton}>
          <Ionicons name="notifications-outline" size={24} color={theme.colors.text} />
          <View style={styles.badge} />
        </Pressable>
      </View>

      <View style={styles.searchContainer}>
        <SearchBar
          value={searchQuery}
          onChangeText={setSearchQuery}
          placeholder="Search by location..."
          onFilterPress={() => router.push('/search')}
        />
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.filtersContainer}
      >
        {quickFilters.map(filter => (
          <Pressable
            key={filter.value}
            style={({ pressed }) => [styles.filterChip, pressed && styles.filterChipPressed]}
            onPress={() => router.push('/search')}
          >
            <Ionicons name={filter.icon as any} size={18} color={theme.colors.primary} />
            <Text style={styles.filterText}>{filter.label}</Text>
          </Pressable>
        ))}
      </ScrollView>

      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Featured Properties</Text>
        <Pressable onPress={() => router.push('/search')}>
          <Text style={styles.seeAll}>See All</Text>
        </Pressable>
      </View>

      <FlatList
        data={properties}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <PropertyCard
            property={item}
            onPress={() => router.push(`/property/${item.id}`)}
            onSavePress={() => toggleSave(item.id)}
            isSaved={isSaved(item.id)}
          />
        )}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        ItemSeparatorComponent={() => <View style={{ height: theme.spacing.md }} />}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.surface,
  },

  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.md,
  },

  greeting: {
    fontSize: theme.fontSizes.sm,
    color: theme.colors.textSecondary,
  },

  title: {
    fontSize: theme.fontSizes['2xl'],
    fontWeight: '700',
    color: theme.colors.text,
    marginTop: 4,
  },

  iconButton: {
    position: 'relative',
    width: 44,
    height: 44,
    borderRadius: theme.borderRadius.full,
    backgroundColor: theme.colors.white,
    justifyContent: 'center',
    alignItems: 'center',
    ...theme.shadows.sm,
  },

  badge: {
    position: 'absolute',
    top: 10,
    right: 10,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: theme.colors.error,
  },

  searchContainer: {
    paddingHorizontal: theme.spacing.md,
    marginBottom: theme.spacing.md,
  },

  filtersContainer: {
    paddingHorizontal: theme.spacing.md,
    gap: theme.spacing.sm,
    marginBottom: theme.spacing.lg,
  },

  filterChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.sm,
    backgroundColor: theme.colors.white,
    borderRadius: theme.borderRadius.full,
    borderWidth: 1.5,
    borderColor: theme.colors.primaryLight,
    ...theme.shadows.sm,
  },

  filterChipPressed: {
    opacity: 0.7,
  },

  filterText: {
    fontSize: theme.fontSizes.sm,
    fontWeight: '600',
    color: theme.colors.primary,
  },

  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: theme.spacing.md,
    marginBottom: theme.spacing.md,
  },

  sectionTitle: {
    fontSize: theme.fontSizes.xl,
    fontWeight: '700',
    color: theme.colors.text,
  },

  seeAll: {
    fontSize: theme.fontSizes.sm,
    fontWeight: '600',
    color: theme.colors.primary,
  },

  listContent: {
    paddingHorizontal: theme.spacing.md,
    paddingBottom: theme.spacing.md,
  },
});
