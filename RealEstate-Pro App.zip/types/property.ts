export interface Property {
  id: string;
  title: string;
  price: number;
  location: {
    city: string;
    state: string;
    address: string;
    coordinates?: {
      lat: number;
      lng: number;
    };
  };
  images: string[];
  type: 'house' | 'apartment' | 'condo' | 'townhouse' | 'land';
  status: 'for-sale' | 'for-rent' | 'sold';
  bedrooms: number;
  bathrooms: number;
  area: number; // in sq ft
  yearBuilt?: number;
  description: string;
  features: string[];
  agent?: {
    name: string;
    phone: string;
    email: string;
    avatar?: string;
  };
  createdAt: string;
  isFeatured?: boolean;
}

export interface SearchFilters {
  location?: string;
  priceMin?: number;
  priceMax?: number;
  propertyType?: Property['type'] | 'all';
  status?: Property['status'] | 'all';
  bedrooms?: number;
  bathrooms?: number;
  areaMin?: number;
  areaMax?: number;
}
