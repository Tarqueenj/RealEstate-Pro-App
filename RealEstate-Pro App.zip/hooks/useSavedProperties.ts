import { useState, useEffect } from 'react';

export function useSavedProperties() {
  const [savedIds, setSavedIds] = useState<string[]>([]);

  const toggleSave = (propertyId: string) => {
    setSavedIds(prev => {
      if (prev.includes(propertyId)) {
        return prev.filter(id => id !== propertyId);
      }
      return [...prev, propertyId];
    });
  };

  const isSaved = (propertyId: string) => {
    return savedIds.includes(propertyId);
  };

  return { savedIds, toggleSave, isSaved };
}
