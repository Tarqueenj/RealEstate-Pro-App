import { useState } from 'react';
import { Property } from '@/types/property';

export function useCompare() {
  const [compareList, setCompareList] = useState<Property[]>([]);

  const addToCompare = (property: Property) => {
    if (compareList.length >= 3) {
      return false;
    }
    if (compareList.find(p => p.id === property.id)) {
      return false;
    }
    setCompareList(prev => [...prev, property]);
    return true;
  };

  const removeFromCompare = (propertyId: string) => {
    setCompareList(prev => prev.filter(p => p.id !== propertyId));
  };

  const clearCompare = () => {
    setCompareList([]);
  };

  const isInCompare = (propertyId: string) => {
    return compareList.some(p => p.id === propertyId);
  };

  return {
    compareList,
    addToCompare,
    removeFromCompare,
    clearCompare,
    isInCompare,
  };
}
