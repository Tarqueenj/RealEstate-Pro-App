import { useState, useEffect } from 'react';
import { Property, SearchFilters } from '@/types/property';
import { propertyService } from '@/services/propertyService';

export function useProperties() {
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadProperties = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await propertyService.getAllProperties();
      setProperties(data);
    } catch (err) {
      setError('Failed to load properties');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProperties();
  }, []);

  return { properties, loading, error, reload: loadProperties };
}

export function useFeaturedProperties() {
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadFeatured = async () => {
      const data = await propertyService.getFeaturedProperties();
      setProperties(data);
      setLoading(false);
    };
    loadFeatured();
  }, []);

  return { properties, loading };
}

export function usePropertySearch() {
  const [results, setResults] = useState<Property[]>([]);
  const [loading, setLoading] = useState(false);
  const [filters, setFilters] = useState<SearchFilters>({
    propertyType: 'all',
    status: 'all',
  });

  const search = async (newFilters?: SearchFilters) => {
    const searchFilters = newFilters || filters;
    setLoading(true);
    try {
      const data = await propertyService.searchProperties(searchFilters);
      setResults(data);
      if (newFilters) {
        setFilters(newFilters);
      }
    } catch (err) {
      setResults([]);
    } finally {
      setLoading(false);
    }
  };

  const updateFilters = (newFilters: Partial<SearchFilters>) => {
    const updated = { ...filters, ...newFilters };
    setFilters(updated);
    search(updated);
  };

  useEffect(() => {
    search();
  }, []);

  return { results, loading, filters, search, updateFilters };
}

export function useProperty(id: string) {
  const [property, setProperty] = useState<Property | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadProperty = async () => {
      const data = await propertyService.getPropertyById(id);
      setProperty(data);
      setLoading(false);
    };
    loadProperty();
  }, [id]);

  return { property, loading };
}
